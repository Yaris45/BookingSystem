<?php
include_once 'sessionstart.php';
if ($_SESSION['user'] == NULL){
  header('Location: loginpage.php');
}
 ?>
<!DOCTYPE html>
<html >
  <head>
    <title>Book List</title>
    <link rel="stylesheet" href="CSS/pages.css">
  </head>
  <body>
    <?php include 'header.php'; ?>
    <div class="wrapper2">
      <div class="column">
        <h1>Book has been returned successfully!</h1>
        <p>To reserve your next book, head over to the: <a class="link" href="booklist.php">Book List</a>
        <p>To see all your book reservations in one place, head over to: <a class="link" href="myaccountpage.php">My Account</a> 
      </div>
      <div class="column">
      </div>
    </div>
    
  </body>
</html>

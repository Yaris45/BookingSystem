<?php

include_once 'sessionstart.php'; //Calling the file once to be used throughout the running of this booklist PHP file. 

if ($_SESSION['user'] == NULL) {
  header('Location: loginpage.php');
}

if (isset($_POST["button"]))
{
   $_SESSION['bookid'] = $_POST["button"];
   header('Location: reservebook.php');  //Directed to this PHP file/page once user wants to reserve a book. 
}
?>


<!DOCTYPE html>
<html>
    <head>
        <title>List of Books </title>
        <link rel="stylesheet" href="CSS/pages.css">
    </head>

<body>
  <?php include 'header.php'; ?>
  <div class="wrapper3">
    <h1>Book list</h1>
    <hr>
    <table>
                <tr>
                    <th>ISBN</th>
                    <th>Title</th>
                    <th>Author</th>
                    <th></th>
                </tr>
                <?php
                require("connectdb.php"); //Connecting to the database needed to call the books. 
                
                $sql = "SELECT ID_book, title, CONCAT(author_first_name,' ',author_last_name) AS author from books";
                
                
                
                $results_per_page = 5;
                $query = "select *from books";  
                $result = mysqli_query($con, $query);  
                $number_of_result = mysqli_num_rows($result);  
              
                $number_of_page = ceil ($number_of_result / $results_per_page);   
  
    if (!isset ($_GET['page']) ) {  
        $page = 1;  
    } else {  
        $page = $_GET['page'];  
    }  
   
    $page_first_result = ($page-1) * $results_per_page;  
  
  
    $query = "SELECT ID_book, title, CONCAT(author_first_name,' ',author_last_name) AS author from books LIMIT " . $page_first_result . ',' . $results_per_page;  
    $result = mysqli_query($con, $query);  
      
    while($row = $result->fetch_assoc()){
        echo "<tr>";
        echo "<td>" . $row['ID_book'] . "</td>";
        echo "<td>" . $row['title'] . "</td>";
        echo "<td>" . $row['author'] . "</td>";
       // echo "<td>" . $row['category'] . "</td>";
        echo "<td>" . '<form action=' . htmlspecialchars($_SERVER["PHP_SELF"]) . ' method="post"> <button type="submit" name="button" value=' . $row["ID_book"] . ' class="rentbutton">RESERVE BOOK</button> </form>' . "</td>";
        echo "</tr>";
        }
  

    for($page = 1; $page<= $number_of_page; $page++) {  
        echo '<a href = "booklist.php?page=' . $page . '">' . $page . ' </a>';  
    }  
                ?>
    </table>
  </div>
  
</body>

</html>

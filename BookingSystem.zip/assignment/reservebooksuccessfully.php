<?php
include_once 'sessionstart.php';
if ($_SESSION['user'] == NULL){
  header('Location: loginpage.php');
}
 ?>
<!DOCTYPE html>
<html >
  <head>
    <title>Book List</title>
    <link rel="stylesheet" href="CSS/pages.css">
  </head>
  <body>
    <?php include 'header.php'; ?>
    <div class="wrapper2">
      <div class="column">
        <h1>This book has been reserved succesfully!</h1>
        <p>To continue searching for other books, head over to: <a class="link" href="booklist.php">Book list</a>
        <p>To see all your reserved books, please head over to:  <a class="link" href="myaccountpage.php">My Account</a>
      </div>
      <div class="column">
      </div>
    </div>
    
  </body>
</html>

<?php include 'login.php'; ?>

<!doctype html>
<html>
    <head>
        <title> Welcome!</title>
        <link rel="stylesheet" href="CSS/pages.css"> 
    </head>

    <body>
        <div class="wrapper2">
            <div class="column">
                    <h1>Please login to reserve a book!</h1>
                    <p>Please login or register to start taking out a book!</p>
            </div>
    
            <?php include 'formforlogin.php'; ?>
        </div>

    </body>
</html> 

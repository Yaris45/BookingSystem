<?php
echo '<header>
  <nav class="top-navbar">
  <ul>
    <li><a class = "navlink" href="logout.php">LOG OUT</a></li>
    <li><a class = "navlink" href="myaccountpage.php">MY ACCOUNT</a></li>
    <li><a class = "navlink" href="booklist.php">BOOK LIST</a></li>
    <li><a class = "navlink" href="homepageindex.php">HOME</a></li>
  </ul>
  </nav>
</header>';
 ?>

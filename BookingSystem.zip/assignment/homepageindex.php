<?php
include_once 'sessionstart.php';
if ($_SESSION['user'] == NULL) {
  header('Location: loginpage.php');
}
 ?>
    <!doctype html>
    <html>
    <head>
    <title>Homepage</title>
    <link rel="stylesheet" href="CSS/pages.css">
    <script>
window.onload = function() {
document.getElementById("searchInput").focus();
};
</script>
    </head>
    <body>
    <?php include 'header.php'; ?>
    <div class="wrapper">
      <div class="logo">
        <a class="navlink" href="homepageindex.php" title="Your Web Library">SEARCH HERE!</a>
      </div>
        <form class="search" action="searchfunction.php" method="post">
          <div>
            <input id="searchInput" type="search" name="q" value="" placeholder="What book are you looking for?">
            <button id="searchButton" type="submit" style="border: 0; background: transparent">
            <img src="CSS/search.png" width="25px" height="25px" alt="search"/>
            </button>
          </div>
          <input type="radio" name="search_type" value="author_last_name" checked>Search by Author
          <input type="radio" name="search_type" value="title"> by Title
        </form>
    </div>
    
    </body>
    </html>

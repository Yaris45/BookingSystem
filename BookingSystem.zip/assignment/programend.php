<?php
include_once 'login.php';
if ($_SESSION['user'] == NULL) {
  header('Location: loginpage.php');
}
 ?>

<!doctype html>
<html>

    <head>
        <title> Goodbye!</title>
        <link rel="stylesheet" href="CSS/pages.css">
    </head>

<body>
    <div class="wrapper2">
        <div class="intro column">
        <h1>P L A C E H O L D E R</h1>
    </div>
        <?php include 'formforlogin.php'; ?>
    </div>
 
</body>
</html>

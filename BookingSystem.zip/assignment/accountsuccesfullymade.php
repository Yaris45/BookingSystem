<?php include 'login.php';
if ($_SESSION['user'] == NULL) {
  header('Location: loginpage.php'); //User will be redirected to this PHP page, In this case, the login page. 
}
?>


<!DOCTYPE html>
<html>
    <head>
        <title>Register Now!</title>
            <link rel="stylesheet" href="CSS/pages.css">
    </head>

    <body>
       
        <div class="wrapper2">
            <div class="intro column">
                <h1>Congratulations!</h1>
                <p>Your account has been successfully made and activated!</p>
            </div>
                <?php include 'formforlogin.php'; ?>
        </div>
   
    </body>
</html>

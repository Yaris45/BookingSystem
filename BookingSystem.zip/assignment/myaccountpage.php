<?php
include_once 'sessionstart.php';
require_once('connectdb.php');
if ($_SESSION['user'] == NULL) {
  header('Location: loginpage.php');
}
if (isset($_POST["button"]))
{
   $_SESSION['transactionid'] = $_POST["button"];
   header('Location: returnbook.php');
}
 ?>
<!DOCTYPE html>
<html>
  <head>
    <title>My Account</title>
    <link rel="stylesheet" href="CSS/pages.css">
  </head>
  <body>
    <?php include 'header.php'; ?>
    <div class="wrapper3">
      
    
    <h1>My Account</h1>
      <hr>
      <h2>Reserved Books:</h2>
      <?php
     $userid = $_SESSION['userid'];
     
     
     $sql = "
     SELECT transactions.ID_transaction, books.ID_book, books.title,
     CONCAT(books.author_last_name,' ',books.author_first_name) AS author,
     transactions.Date_start FROM transactions NATURAL JOIN books
     WHERE transactions.Date_end IS NULL AND transactions.ID_User = '$userid' ";
     if(!$result = $con->query($sql)){
     die('There was an error running the query [' . $con->error .']');
   }
   if($result->num_rows > 0) {
     echo "<table>
         <th>ISBN:</th>
         <th>Title:</th>
         <th>Author:</th>
         <th>Date Reserved:</th>
       </tr>";
   while($row = $result->fetch_assoc()){
   echo "<tr>";
   echo "<td>" . $row['ID_book'] . "</td>";
   echo "<td>" . $row['title'] . "</td>";
   echo "<td>" . $row['author'] . "</td>";
   echo "<td>" . $row['Date_start'] . "</td>";
   echo "<td>" . '<form action=' . htmlspecialchars($_SERVER["PHP_SELF"]) . ' method="post"> <button type="submit" name="button" value=' . $row["ID_transaction"] . ' class="rentbutton">RETURN BOOK</button> </form>' . "</td>";
   echo "</tr>";
   }
  echo  "</table>";
   }
   else {
     echo "No reservations to display!";
   }
     $result->free();
     $con->close();
     ?>
    </div>
    
  </body>
</html>
